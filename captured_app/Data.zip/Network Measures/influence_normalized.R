setwd("D:/Dropbox/_Silvia/Work/Projects/CivicDev Hackathon_7-8 Oct 2017/Data/Network Measures")

AS_net_2009 <- read.csv("AS_net_2009.csv", header = T)
AS_net_2009$infl_norm = (AS_net_2009$Influence-min(AS_net_2009$Influence))/(max(AS_net_2009$Influence)-min(AS_net_2009$Influence))
write.csv(AS_net_2009, "AS_net_2009.csv")

AS_net_2010 <- read.csv("AS_net_2010.csv", header = T)
AS_net_2010$infl_norm = (AS_net_2010$Influence-min(AS_net_2010$Influence))/(max(AS_net_2010$Influence)-min(AS_net_2010$Influence))
write.csv(AS_net_2010, "AS_net_2010.csv")

AS_net_2011 <- read.csv("AS_net_2011.csv", header = T)
AS_net_2011$infl_norm = (AS_net_2011$Influence-min(AS_net_2011$Influence))/(max(AS_net_2011$Influence)-min(AS_net_2011$Influence))
write.csv(AS_net_2011, "AS_net_2011.csv")

AS_net_2012 <- read.csv("AS_net_2012.csv", header = T)
AS_net_2012$infl_norm = (AS_net_2012$Influence-min(AS_net_2012$Influence))/(max(AS_net_2012$Influence)-min(AS_net_2012$Influence))
write.csv(AS_net_2012, "AS_net_2012.csv")

BS_net_2009 <- read.csv("BS_net_2009.csv", header = T)
BS_net_2009$infl_norm = (BS_net_2009$Influence-min(BS_net_2009$Influence))/(max(BS_net_2009$Influence)-min(BS_net_2009$Influence))
write.csv(BS_net_2009, "BS_net_2009.csv")

BS_net_2010 <- read.csv("BS_net_2010.csv", header = T)
BS_net_2010$infl_norm = (BS_net_2010$Influence-min(BS_net_2010$Influence))/(max(BS_net_2010$Influence)-min(BS_net_2010$Influence))
write.csv(BS_net_2010, "BS_net_2010.csv")

BS_net_2011 <- read.csv("BS_net_2011.csv", header = T)
BS_net_2011$infl_norm = (BS_net_2011$Influence-min(BS_net_2011$Influence))/(max(BS_net_2011$Influence)-min(BS_net_2011$Influence))
write.csv(BS_net_2011, "BS_net_2011.csv")

BS_net_2012 <- read.csv("BS_net_2012.csv", header = T)
BS_net_2012$infl_norm = (BS_net_2012$Influence-min(BS_net_2012$Influence))/(max(BS_net_2012$Influence)-min(BS_net_2012$Influence))
write.csv(BS_net_2012, "BS_net_2012.csv")

CW_net_2009 <- read.csv("CW_net_2009.csv", header = T)
CW_net_2009$infl_norm = (CW_net_2009$Influence-min(CW_net_2009$Influence))/(max(CW_net_2009$Influence)-min(CW_net_2009$Influence))
write.csv(CW_net_2009, "CW_net_2009.csv")

CW_net_2010 <- read.csv("CW_net_2010.csv", header = T)
CW_net_2010$infl_norm = (CW_net_2010$Influence-min(CW_net_2010$Influence))/(max(CW_net_2010$Influence)-min(CW_net_2010$Influence))
write.csv(CW_net_2010, "CW_net_2010.csv")

CW_net_2011 <- read.csv("CW_net_2011.csv", header = T)
CW_net_2011$infl_norm = (CW_net_2011$Influence-min(CW_net_2011$Influence))/(max(CW_net_2011$Influence)-min(CW_net_2011$Influence))
write.csv(CW_net_2011, "CW_net_2011.csv")

CW_net_2012 <- read.csv("CW_net_2012.csv", header = T)
CW_net_2012$infl_norm = (CW_net_2012$Influence-min(CW_net_2012$Influence))/(max(CW_net_2012$Influence)-min(CW_net_2012$Influence))
write.csv(CW_net_2012, "CW_net_2012.csv")

PP_net_2009 <- read.csv("PP_net_2009.csv", header = T)
PP_net_2009$infl_norm = (PP_net_2009$Influence-min(PP_net_2009$Influence))/(max(PP_net_2009$Influence)-min(PP_net_2009$Influence))
write.csv(PP_net_2009, "PP_net_2009.csv")

PP_net_2010 <- read.csv("PP_net_2010.csv", header = T)
PP_net_2010$infl_norm = (PP_net_2010$Influence-min(PP_net_2010$Influence))/(max(PP_net_2010$Influence)-min(PP_net_2010$Influence))
write.csv(PP_net_2010, "PP_net_2010.csv")

PP_net_2011 <- read.csv("PP_net_2011.csv", header = T)
PP_net_2011$infl_norm = (PP_net_2011$Influence-min(PP_net_2011$Influence))/(max(PP_net_2011$Influence)-min(PP_net_2011$Influence))
write.csv(PP_net_2011, "PP_net_2011.csv")

PP_net_2012 <- read.csv("PP_net_2012.csv", header = T)
PP_net_2012$infl_norm = (PP_net_2012$Influence-min(PP_net_2012$Influence))/(max(PP_net_2012$Influence)-min(PP_net_2012$Influence))
write.csv(PP_net_2012, "PP_net_2012.csv")

CZ_net_2009 <- read.csv("CZ_net_2009.csv", header = T)
CZ_net_2009$infl_norm = (CZ_net_2009$Influence-min(CZ_net_2009$Influence))/(max(CZ_net_2009$Influence)-min(CZ_net_2009$Influence))
write.csv(CZ_net_2009, "CZ_net_2009.csv")

CZ_net_2010 <- read.csv("CZ_net_2010.csv", header = T)
CZ_net_2010$infl_norm = (CZ_net_2010$Influence-min(CZ_net_2010$Influence))/(max(CZ_net_2010$Influence)-min(CZ_net_2010$Influence))
write.csv(CZ_net_2010, "CZ_net_2010.csv")

CZ_net_2011 <- read.csv("CZ_net_2011.csv", header = T)
CZ_net_2011$infl_norm = (CZ_net_2011$Influence-min(CZ_net_2011$Influence))/(max(CZ_net_2011$Influence)-min(CZ_net_2011$Influence))
write.csv(CZ_net_2011, "CZ_net_2011.csv")

CZ_net_2012 <- read.csv("CZ_net_2012.csv", header = T)
CZ_net_2012$infl_norm = (CZ_net_2012$Influence-min(CZ_net_2012$Influence))/(max(CZ_net_2012$Influence)-min(CZ_net_2012$Influence))
write.csv(CZ_net_2012, "CZ_net_2012.csv")

SK_net_2009 <- read.csv("SK_net_2009.csv", header = T)
SK_net_2009$infl_norm = (SK_net_2009$Influence-min(SK_net_2009$Influence))/(max(SK_net_2009$Influence)-min(SK_net_2009$Influence))
write.csv(SK_net_2009, "SK_net_2009.csv")

SK_net_2010 <- read.csv("SK_net_2010.csv", header = T)
SK_net_2010$infl_norm = (SK_net_2010$Influence-min(SK_net_2010$Influence))/(max(SK_net_2010$Influence)-min(SK_net_2010$Influence))
write.csv(SK_net_2010, "SK_net_2010.csv")

SK_net_2011 <- read.csv("SK_net_2011.csv", header = T)
SK_net_2011$infl_norm = (SK_net_2011$Influence-min(SK_net_2011$Influence))/(max(SK_net_2011$Influence)-min(SK_net_2011$Influence))
write.csv(SK_net_2011, "SK_net_2011.csv")

SK_net_2012 <- read.csv("SK_net_2012.csv", header = T)
SK_net_2012$infl_norm = (SK_net_2012$Influence-min(SK_net_2012$Influence))/(max(SK_net_2012$Influence)-min(SK_net_2012$Influence))
write.csv(SK_net_2012, "SK_net_2012.csv")